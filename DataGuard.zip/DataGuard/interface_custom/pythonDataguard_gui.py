import tkinter as tk
from tkinter import messagebox
import subprocess
import os

def confirm_and_run(script_path, action_name):
    """Exibe uma confirmação antes de executar o script e mostra o resultado."""
    # Exibe uma caixa de diálogo de confirmação
    confirm = messagebox.askyesno("Confirmação", f"Tem certeza de que deseja {action_name}?")
    
    if confirm:
        try:
            # Executa o script
            result = subprocess.run(['python', script_path], capture_output=True, text=True)
            # Exibe o resultado no campo de texto da interface
            output_text.insert(tk.END, f"Resultado de {action_name}:\n{result.stdout}\n")
            # Exibe mensagem de sucesso
            messagebox.showinfo("Sucesso", f"Ação {action_name} concluída com sucesso!")
        except Exception as e:
            # Exibe mensagem de erro
            output_text.insert(tk.END, f"Erro ao executar {action_name}: {e}\n")
            messagebox.showerror("Erro", f"Erro ao executar {action_name}!")
    else:
        output_text.insert(tk.END, f"Ação {action_name} cancelada.\n")

# Cria a janela principal
root = tk.Tk()
root.title("DataGuard Interface")
root.geometry("400x300")

# Botões para executar os scripts
check_packs_button = tk.Button(root, text="Verificar Pacotes", command=lambda: confirm_and_run(os.path.join('AttAuto', 'checkPacks.py'), "Verificar Pacotes"))
check_update_button = tk.Button(root, text="Verificar Atualizações", command=lambda: confirm_and_run(os.path.join('AttAuto', 'checkUpdate.py'), "Verificar Atualizações"))
send_alert_button = tk.Button(root, text="Enviar Alerta", command=lambda: confirm_and_run(os.path.join('envioEmails', 'custom_warnings.py'), "Enviar Alerta"))

# Disposição dos botões
check_packs_button.pack(pady=10)
check_update_button.pack(pady=10)
send_alert_button.pack(pady=10)

# Caixa de texto para exibir a saída
output_text = tk.Text(root, height=10, width=50)
output_text.pack(pady=10)

# Inicia o loop da GUI
root.mainloop()
