import smtplib
from email.mime.text import MIMEText

def send_alert_email():
    sender = "bolachacatapimbas@gmail.com"
    receiver = "betocagnato@gmail.com"
    app_password = "vbhf jzqh mxbg rtsn"

    # Cria a mensagem do email
    message = MIMEText("Alerta: Tentativa de acesso não autorizado!")
    message['Subject'] = "Alerta de Segurança"
    message['From'] = sender
    message['To'] = receiver

    try:
        # Conecta ao servidor SMTP do Gmail
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()  # Inicia o TLS
            server.login(sender, app_password)  # Faz o login com a senha de app
            server.sendmail(sender, receiver, message.as_string())  # Envia o email
            print("Email enviado com sucesso!")
    except Exception as e:
        print(f"Erro ao enviar email: {e}")

send_alert_email()
