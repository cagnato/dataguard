import subprocess

def check_updates():
    # Executa o comando winget para listar os pacotes instalados
    result = subprocess.run(['winget', 'list'], capture_output=True, text=True)

    # Verifica se o comando foi executado com sucesso
    if result.returncode == 0:
        print("Pacotes instalados:")
        print(result.stdout)  # Exibe o resultado do comando 'winget list' no console
    else:
        print("Erro ao verificar pacotes.")

check_updates()
