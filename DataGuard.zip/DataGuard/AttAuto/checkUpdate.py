import os
import shutil

def backup_file(file_path):
    """Cria um backup do arquivo especificado, se ele existir e contiver dados."""
    if os.path.exists(file_path):
        if os.path.getsize(file_path) > 0:  # Verifica se o arquivo tem conteúdo
            backup_path = f"{file_path}.backup"
            shutil.copy(file_path, backup_path)
            print(f"Backup criado: {backup_path}")
            return backup_path
        else:
            print(f"Erro: O arquivo {file_path} está vazio.")
            return None
    else:
        print(f"Erro: O arquivo {file_path} não foi encontrado.")
        return None

def update_file(file_path, new_content):
    """Atualiza o conteúdo do arquivo e cria um backup antes."""
    backup_path = backup_file(file_path)

    if backup_path:
        # Atualiza o arquivo com o novo conteúdo
        with open(file_path, 'w') as file:
            file.write(new_content)
        print(f"Arquivo atualizado: {file_path}")
    else:
        print(f"Não foi possível atualizar o arquivo {file_path}.")

# Exemplo de uso
file_path = r'batata.txt'  # Caminho para o arquivo
new_content = "Novo conteúdo para o arquivo"
update_file(file_path, new_content)
