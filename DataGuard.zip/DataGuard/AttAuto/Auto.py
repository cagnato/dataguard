import subprocess

def apply_updates():
    # Aplica atualizações para todos os pacotes disponíveis
    result = subprocess.run(['winget', 'upgrade', '--all'], capture_output=True, text=True)

    if result.returncode == 0:
        print("Atualizações aplicadas com sucesso.")
    else:
        print("Erro ao aplicar atualizações.")

apply_updates()
