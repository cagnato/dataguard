from cryptography.fernet import Fernet
import requests

# Funções de criptografia local
def generate_key():
    """Gera e retorna uma chave de criptografia."""
    return Fernet.generate_key()

def encrypt_data(data, key):
    """Criptografa os dados usando a chave fornecida."""
    cipher = Fernet(key)
    encrypted_data = cipher.encrypt(data.encode())
    print(f"Dados criptografados localmente: {encrypted_data}")
    return encrypted_data

def decrypt_data(encrypted_data, key):
    """Descriptografa os dados usando a chave fornecida."""
    cipher = Fernet(key)
    decrypted_data = cipher.decrypt(encrypted_data).decode()
    print(f"Dados descriptografados localmente: {decrypted_data}")
    return decrypted_data

# Funções para envio e recebimento de dados com criptografia
def send_encrypted_data(url, data, key):
    """Criptografa os dados e os envia para o servidor via HTTPS."""
    cipher = Fernet(key)
    encrypted_data = cipher.encrypt(data.encode())

    # Envia os dados criptografados
    response = requests.post(url, data={'encrypted_data': encrypted_data})
    print(f"Dados enviados para {url}")
    return response

def receive_and_decrypt_data(response, key):
    """Recebe e descriptografa os dados do servidor."""
    cipher = Fernet(key)
    encrypted_data = response.content
    decrypted_data = cipher.decrypt(encrypted_data).decode()
    print(f"Dados recebidos e descriptografados: {decrypted_data}")
    return decrypted_data

# Exemplo de uso combinado:
key = generate_key()  # Gera a chave para criptografar/descriptografar

# 1. Criptografar e armazenar dados localmente
data = "Dados confidenciais"
encrypted_data = encrypt_data(data, key)

# Armazene os dados criptografados localmente (pode ser em um arquivo)
# ...

# 2. Transmissão segura dos dados criptografados
url = "https://seuservidor.com/api"
response = send_encrypted_data(url, data, key)

# 3. Receber e descriptografar a resposta do servidor
receive_and_decrypt_data(response, key)
